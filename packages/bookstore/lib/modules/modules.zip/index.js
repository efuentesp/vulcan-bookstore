import "./routes";
import "./components";
import "./category/collection.js";
import "./product/collection.js";
