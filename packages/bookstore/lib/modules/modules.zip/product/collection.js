import {
  createCollection,
  getDefaultResolvers,
  getDefaultMutations
} from "meteor/vulcan:core";
import schema from "./schema.js";
import "./fragments.js";
import "./permissions.js";

const ProductCollection = createCollection({
  //collectionName: "Products",
  typeName: "Product",
  schema,
  resolvers: getDefaultResolvers({ typeName: "Product" }),
  mutations: getDefaultMutations({ typeName: "Product" })
});

ProductCollection.addDefaultView(terms => {
  return {
    options: { sort: { createdAt: -1 } }
  };
});

export default ProductCollection;
