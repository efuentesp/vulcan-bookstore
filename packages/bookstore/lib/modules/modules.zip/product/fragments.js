import { registerFragment } from "meteor/vulcan:core";

registerFragment(`
   fragment ProductItemFragment on Product {
     _id
     createdAt
     category
     picture
     sku
     name
     description
     price
   }
`);
