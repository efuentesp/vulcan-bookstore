import {
  createCollection,
  getDefaultResolvers,
  getDefaultMutations
} from "meteor/vulcan:core";
import schema from "./schema.js";
import "./fragments.js";
import "./permissions.js";

const CategoryCollection = createCollection({
  //collectionName: "Categories",
  typeName: "Category",
  schema,
  resolvers: getDefaultResolvers({ typeName: "Category" }),
  mutations: getDefaultMutations({ typeName: "Category" })
});

CategoryCollection.addDefaultView(terms => {
  return {
    options: { sort: { createdAt: -1 } }
  };
});

export default CategoryCollection;
