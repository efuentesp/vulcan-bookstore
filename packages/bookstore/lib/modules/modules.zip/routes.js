import { addRoute } from "meteor/vulcan:core";

// addRoute({
//   name: "home",
//   path: "/",
//   componentName: "ProductCategoriesScreen"
// });

// addRoute({
//   name: "productcategoriesscreen",
//   path: "/productcategoriesscreen",
//   componentName: "ProductCategoriesScreen"
// });
